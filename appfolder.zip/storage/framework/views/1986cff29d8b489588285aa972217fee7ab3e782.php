

<?php $__env->startSection('content'); ?>
  <div class="card shadow mb-4 col-12">
    <div class="card-header">
      <a href="<?php echo e(route('keperluan.index')); ?>" class="btn btn-warning text-white"><i class="bi bi-box-arrow-left"></i>
        Kembali</a>
    </div>
    <div class="card-body">
      <h5 class="card-title">Form Tambah Keperluan Warga</h5>

      <!-- General Form Elements -->
      <form action="<?php echo e(route('keperluan.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row mb-3">
          <label for="inputText" class="col-sm-2 col-form-label">Keperluan</label>
          <div class="col-sm-10">
            <input type="text" name="keperluan" value="<?php echo e(old('keperluan')); ?>" class="form-control">
          </div>
        </div>


        <div class="row mb-3">
          <label class="col-sm-2 col-form-label"></label>
          <div class="col-sm-10">
            <button type="submit" class="btn btn-primary">Save</button>
          </div>
        </div>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\wargabatam\resources\views/pages/keperluan/create.blade.php ENDPATH**/ ?>