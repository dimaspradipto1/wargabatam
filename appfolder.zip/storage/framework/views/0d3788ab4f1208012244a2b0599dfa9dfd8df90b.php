

<?php $__env->startSection('content'); ?>
  <div class="card shadow mb-4 col-12">
    <div class="card-header">
      <a href="/kelahiran" class="btn btn-warning text-white"><i class="bi bi-box-arrow-left"></i> Kembali</a>
    </div>
    <div class="card-body">
      <h5 class="card-title">Form Tambah Bayi</h5>

      <!-- General Form Elements -->
      <form action="<?php echo e(route('kelahiran.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="row mb-3">
          <label for="inputText" class="col-sm-2 col-form-label">Kepala Keluarga</label>
          <div class="col-sm-10">
            <select class="form-select" name="kartukeluarga_id">
              <option selected>-- Pilih Kepala Keluarga --</option>
              <?php $__currentLoopData = $kartukeluarga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($kk->id); ?>"><?php echo e($kk->kepala_keluarga); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>

        <div class="row mb-3">
          <label for="inputText" class="col-sm-2 col-form-label">Nama Bayi</label>
          <div class="col-sm-10">
            <input type="text" name="nama_bayi" value="<?php echo e(old('nama_bayi')); ?>" class="form-control" required>
            <div class="invalid-feedback">Masukkan Nama Bayi!!!</div>
          </div>
        </div>

        <div class="row mb-3">
          <label for="inputText" class="col-sm-2 col-form-label">Tempat Lahir</label>
          <div class="col-sm-10">
            <input type="text" name="tempat_lahir" value="<?php echo e(old('tempat_lahir')); ?>" class="form-control" required>
            <div class="invalid-feedback">Masukkan Tempat Lahir!!!</div>
          </div>
        </div>

        <div class="row mb-3">
          <label for="inputText" class="col-sm-2 col-form-label">Tanggal Lahir</label>
          <div class="col-sm-10">
            <input type="date" name="tanggal_lahir" value="<?php echo e(old('tanggal_lahir')); ?>" class="form-control" required>
            <div class="invalid-feedback">Masukkan Tanggal Lahir!!!</div>
          </div>
        </div>

        <div class="row mb-3">
          <label for="inputText" class="col-sm-2 col-form-label">Jenis Kelamin</label>
          <div class="col-sm-10">
            <select class="form-select" name="jenis_kelamin">
              <option selected>-- Pilih Jenis Kelamin --</option>
              <option value="Laki-Laki">Laki-Laki</option>
              <option value="Perempuan">Perempuan</option>
            </select>
          </div>
        </div>

        <div class="row mb-3">
          <label class="col-sm-2 col-form-label"></label>
          <div class="col-sm-10">
            <button type="submit" class="btn btn-primary">Save</button>
          </div>
        </div>

      </form>

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\warga\resources\views/pages/kelahiran/create.blade.php ENDPATH**/ ?>