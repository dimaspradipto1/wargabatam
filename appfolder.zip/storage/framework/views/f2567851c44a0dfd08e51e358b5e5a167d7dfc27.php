

<?php $__env->startSection('content'); ?>
  <div class="card shadow mb-4 col-12">
    <div class="card-header">
      <a href="/pindah" class="btn btn-warning text-white"><i class="bi bi-box-arrow-left"></i> Kembali</a>
    </div>
    <div class="card-body">
      <h5 class="carad-title">Form Tambah Warga Pendatang</h5>

      <!-- General Form Elements -->
      <form action="<?php echo e(route('pindah.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="row mb-3">
          <label for="inputText" class="col-sm-2 col-form-label">Warga</label>
          <div class="col-sm-10">
            <select class="form-select selectpicker w-100" name="warga_id" data-live-search="true">
              <option selected>-- Pilih Warga --</option>
              <?php $__currentLoopData = $warga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($w->id); ?>"><?php echo e($w->nik); ?> - <?php echo e($w->nama); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <div class="invalid-feedback">Masukkan nama pelapor !!!</div>
          </div>
        </div>

        <div class="row mb-3">
          <label for="inputText" class="col-sm-2 col-form-label">Tanggal Pindah</label>
          <div class="col-sm-10">
            <input type="date" name="tanggal_pindah" value="<?php echo e(old('tanggal_pindah')); ?>" class="form-control" required>
            <div class="invalid-feedback">Masukkan Tanggal Pindah!!!</div>
          </div>
        </div>

        <div class="row mb-3">
          <label for="inputText" class="col-sm-2 col-form-label">Alamat Pindah</label>
          <div class="col-sm-10">
            <input type="text" name="alamat_pindah" value="<?php echo e(old('alamat_pindah')); ?>" placeholder="Alamat Pindah"
              class="form-control" required>
            <div class="invalid-feedback">Masukkan Alamat Pindah!!!</div>
          </div>
        </div>

        <div class="row mb-3">
          <label for="inputText" class="col-sm-2 col-form-label">Alasan</label>
          <div class="col-sm-10">
            <input type="text" name="alasan_pindah" value="<?php echo e(old('alasan_pindah')); ?>" placeholder="Alasan Pindah"
              class="form-control" required>
            <div class="invalid-feedback">Masukkan Alasan Kamu Pindah!!!</div>
          </div>
        </div>

        <div class="row mb-3">
          <label class="col-sm-2 col-form-label"></label>
          <div class="col-sm-10">
            <button type="submit" class="btn btn-primary">Save</button>
          </div>
        </div>

      </form>

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\wargabatam\resources\views/pages/pindah/create.blade.php ENDPATH**/ ?>