

<?php $__env->startSection('content'); ?>
  <div class="card shadow mb-4 col-12">
    <div class="card-header py-3">

    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table id="table" class="table table-striped" style="width:100%">
          <thead>
            <tr>
              <th>No</th>
              <th>Nama </th>
              <th>Email </th>
              <th>Status </th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th><?php echo e($loop->iteration); ?></th>
                <th><?php echo e($u->name); ?></th>
                <th><?php echo e($u->email); ?></th>
                <th><?php echo e($u->role); ?></th>
                <th>
                  <a href="user/<?php echo e($u->id); ?>/edit" class="btn btn-warning text-white"><i class="bi bi-pencil"></i></a>
                  <form action="user/<?php echo e($u->id); ?>" method="POST" class="d-inline mt-2">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button type="submit" class="btn btn-danger"><i class="bi bi-trash"></i></button>
                  </form>
                </th>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\wargabatam\resources\views/pages/user/index.blade.php ENDPATH**/ ?>