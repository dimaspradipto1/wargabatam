

<?php $__env->startSection('content'); ?>
  <div class="card shadow mb-4 col-12">
    <div class="card-header py-3">
      <a href="<?php echo e(route('suratpengantarrt.create')); ?>" class="btn btn-success"><i class="bi bi-plus"></i> Tambah</a>
      
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table id="table" class="table table-striped" style="width:100%">
          <thead>
            <tr>
              <th>No</th>
              <th>NO Surat</th>
              <th>NIK</th>
              <th>Nama Warga</th>
              <th>Keperluan</th>
              <th>cetak</th>
              <?php if(Auth::user()->role == 'admin' || Auth::user()->role == 'rt'): ?>
                <th>Aksi</th>
              <?php endif; ?>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $suratpengantarrt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th><?php echo e($loop->iteration); ?></th>
                <th><?php echo e($rt->no_surat); ?></th>
                
                <th><?php echo e($rt->warga->nik); ?></th>
                <th><?php echo e($rt->warga_nama); ?></th>
                <th><?php echo e($rt->keperluan->keperluan); ?></th>

                <th>
                  <a href="<?php echo e(route('cetak_pdf', $rt->id)); ?>" class="btn btn-dark text-white my-2"><i
                      class="bi bi-printer"></i></a>
                </th>
                <?php if(Auth::user()->role == 'admin' || Auth::user()->role == 'rt'): ?>
                  <th>
                    <a href="suratpengantarrt/<?php echo e($rt->id); ?>/edit" class="btn btn-warning text-white my-2"><i
                        class="bi bi-pencil"></i></a>

                    <form action="suratpengantarrt/<?php echo e($rt->id); ?>" method="POST" class="d-inline">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('delete'); ?>
                      <button type="submit" class="btn btn-danger"><i class="bi bi-trash"></i></button>
                    </form>
                  </th>
                <?php endif; ?>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\warga\resources\views/pages/suratpengantarrt/index.blade.php ENDPATH**/ ?>