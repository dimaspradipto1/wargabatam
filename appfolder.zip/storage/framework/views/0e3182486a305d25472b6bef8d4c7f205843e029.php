

<?php $__env->startSection('content'); ?>
  <div class="card shadow mb-4 col-12">
    <div class="card-header">
      <a href="/anggota" class="btn btn-warning text-white"><i class="bi bi-box-arrow-left"></i> Kembali</a>
    </div>
    <div class="card-body">
      <h5 class="card-title">Anggota Keluarga</h5>

      <!-- General Form Elements -->
      <form>
        <div class="row mb-3">
          <label for="inputText" class="col-sm-2 col-form-label">No Kartu Keluarga</label>
          <div class="col-sm-10">
            <select class="form-select selectpicker w-100" name="no_kk" data-live-search="true">
              <option selected>--pilih nomor kk--</option>
              <?php $__currentLoopData = $kartukeluarga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($kk->id); ?>"<?php echo e($kk->id == $anggota->kepala_keluarga_id ? 'selected' : ''); ?>>
                  <?php echo e($kk->no_kk); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>

        <div class="row mb-3">
          <label for="inputText" class="col-sm-2 col-form-label">Alamat</label>
          <div class="col-sm-10">
            <input type="text" name="status_hubungan	"
              value="<?php echo e(old('status_hubungan') ?? $kartukeluarga->status_hubungan); ?>" placeholder="status_hubungan	"
              class="form-control" required>
            <div class="invalid-feedback">Masukkan Alamat Kamu!!!</div>
          </div>
        </div>
      </form>

      <table class="table display nowrap" style="width:100%">
        <thead>
          <tr>
            <th>No</th>
            <th>NIK</th>
            <th>Nama</th>
            <th>Jenis Kelamin</th>
            <th>Status Hubungan</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <?php $__currentLoopData = $kartukeluarga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <th><?php echo e($loop->iteration); ?></th>
              
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\warga\resources\views/pages/kartukeluarga/show.blade.php ENDPATH**/ ?>