

<?php $__env->startSection('content'); ?>
  <div class="card shadow mb-4 col-12">
    <div class="card-header">
      <a href="<?php echo e(route('kartukeluarga.anggota.index', $kartukeluarga->id)); ?>" class="btn btn-warning text-white"><i
          class="bi bi-arrow-left"></i>
        Kembali</a>
    </div>
    <div class="card-body">
      <h5 class="card-title">Form Tambah Angggota Keluarga &raquo; <?php echo e($kartukeluarga->kepala_keluarga); ?></h5>

      <!-- General Form Elements -->
      <form action="<?php echo e(route('kartukeluarga.anggota.store', $kartukeluarga->id)); ?>" method="POST"
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="row mb-3">
          <label for="inputText" class="col-sm-2 col-form-label">Warga</label>
          <div class="col-sm-10">
            <select class="form-select selectpicker w-100" name="warga_id" data-live-search="true">
              <option selected>-- Pilih Warga --</option>
              <?php $__currentLoopData = $warga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($w->id); ?>"><?php echo e($w->nik); ?> - <?php echo e($w->nama); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <div class="invalid-feedback">Masukkan nama warga !!!</div>
          </div>
        </div>

        <div class="row mb-3">
          <label for="inputText" class="col-sm-2 col-form-label">Status Hubungan</label>
          <div class="col-sm-10">
            <select name="status_hubungan" class="form-select selectpicker w-100" data-live-search="true">
              <option selected>-- pilih Status Hubungan --</option>
              <option value="Kepala Keluarga">Kepala Keluarga</option>
              <option value="Istri">Istri</option>
              <option value="Anak">Anak</option>
            </select>
          </div>
        </div>

        <div class="row mb-3">
          <label class="col-sm-2 col-form-label"></label>
          <div class="col-sm-10">
            <button type="submit" class="btn btn-primary">Save</button>
          </div>
        </div>

      </form>

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\warga\resources\views/pages/anggota/create.blade.php ENDPATH**/ ?>