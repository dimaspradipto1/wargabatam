

<?php $__env->startSection('content'); ?>
  <div class="card shadow mb-4 col-12">
    <div class="card-header py-3 mb-3">
      <a href="<?php echo e(route('kartukeluarga.index')); ?>" class="btn btn-warning text-white"><i class="bi bi-arrow-left"></i>
        Kembali</a>
      <a href="<?php echo e(route('kartukeluarga.anggota.create', $kartukeluarga->id)); ?>" class="btn btn-info text-white"><i
          class="bi bi-person-heart"></i> Tambah Anggota
        KK</a>
    </div>

    <form>
      <div class="row mb-3">
        <label for="inputText" class="col-sm-2 col-form-label">Nomor KK | Kepala Keluarga</label>
        <div class="col-sm-5">
          <input type="number" name="no_kk" value="<?php echo e(old('no_kk') ?? $kartukeluarga->no_kk); ?>" class="form-control"
            placeholder="nomor kartu keluarga" required>
          <div class="invalid-feedback">Masukkan nomor KK!!!</div>
        </div>
        <div class="col-sm-5">
          <input type="text" name="kepala_keluarga"
            value="<?php echo e(old('kepala_keluarga') ?? $kartukeluarga->kepala_keluarga); ?>" class="form-control"
            placeholder="kartu keluarga" required>
        </div>
      </div>

      <div class="row mb-3">
        <label for="inputText" class="col-sm-2 col-form-label">Alamat</label>
        <div class="col-sm-10">
          <input type="text" name="alamat" value="<?php echo e(old('alamat') ?? $kartukeluarga->alamat); ?>" placeholder="alamat"
            class="form-control" required>
          <div class="invalid-feedback">Masukkan Alamat Kamu!!!</div>
        </div>
      </div>

      <div class="row mb-3">
        <label for="inputText" class="col-sm-2 col-form-label">RT/RW</label>
        <div class="col-sm-5 mb-3">
          <input type="text" name="rt" value="<?php echo e(old('rt') ?? $kartukeluarga->rt); ?>" class="form-control"
            placeholder="001" required>
          <div class="invalid-feedback">Masukkan RT Kamu!!!</div>
        </div>
        <div class="col-sm-5">
          <input type="text" name="rw" value="<?php echo e(old('rw') ?? $kartukeluarga->rw); ?>" class="form-control"
            placeholder="001" required>
          <div class="invalid-feedback">Masukkan RW Kamu!!!</div>
        </div>
      </div>

      <div class="row mb-3">
        <label for="inputText" class="col-sm-2 col-form-label">Kelurahan</label>
        <div class="col-sm-5">
          <input type="text" name="kelurahan" value="<?php echo e(old('kelurahan') ?? $kartukeluarga->kelurahan); ?>"
            placeholder="kelurahan" class="form-control" required>
          <div class="invalid-feedback">Masukkan kelurahan Kamu!!!</div>
        </div>
        <div class="col-sm-5">
          <input type="text" name="kecamatan" value="<?php echo e(old('kecamatan') ?? $kartukeluarga->kecamatan); ?>"
            placeholder="kecamatan" class="form-control" required>
          <div class="invalid-feedback">Masukkan kelurahan Kamu!!!</div>
        </div>
      </div>
    </form>

    <hr />

    <div class="card-body shadow">
      <div class="table-responsive">
        <table id="table" class="table display nowrap" style="width:100%">
          <thead>
            <tr>
              <th>No</th>
              <th>NIK</th>
              <th>Nama</th>
              <th>Status</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th><?php echo e($loop->iteration); ?></th>
                <th><?php echo e($a->warga->nik); ?></th>
                <th><?php echo e($a->warga->nama); ?></th>
                <th><?php echo e($a->status_hubungan); ?></th>
                <th>
                  <form action="<?php echo e(route('anggota.destroy', $a->id)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button class="btn btn-danger"><i class="bi bi-trash"></i></button>
                  </form>
                </th>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\warga\resources\views/pages/anggota/index.blade.php ENDPATH**/ ?>