

<?php $__env->startSection('content'); ?>
  <div class="card shadow mb-4 col-12">
    <div class="card-header py-3">
      <a href="<?php echo e(route('kelahiran.create')); ?>" class="btn btn-success"><i class="bi bi-plus"></i> Tambah</a>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table id="table" class="table table-striped" style="width:100%">
          <thead>
            <tr>
              <th>No</th>
              <th>Kepala Keluarga</th>
              <th>Nama Bayi</th>
              <th>Tempat Lahir</th>
              <th>Tanggal Lahir</th>
              <th>Jenis Kelamin</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $kelahiran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th><?php echo e($loop->iteration); ?></th>
                <th><?php echo e($k->kartukeluarga->kepala_keluarga); ?></th>
                <th><?php echo e($k->nama_bayi); ?></th>
                <th><?php echo e($k->tempat_lahir); ?></th>
                <th><?php echo e(\Carbon\Carbon::parse($k->tanggal_lahir)->format('d F Y')); ?></th>
                <th><?php echo e($k->jenis_kelamin); ?></th>
                <th>
                  <a href="kelahiran/<?php echo e($k->id); ?>/edit" class="btn btn-warning text-white my-2"><i
                      class="bi bi-pencil"></i></a>
                  <form action="kelahiran/<?php echo e($k->id); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button type="submit" class="btn btn-danger"><i class="bi bi-trash"></i></button>
                  </form>
                </th>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\wargabatam\resources\views/pages/kelahiran/index.blade.php ENDPATH**/ ?>