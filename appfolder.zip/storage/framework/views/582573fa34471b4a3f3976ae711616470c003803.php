<!-- ======= Footer ======= -->
<footer id="footer" class="footer">
  <div class="copyright">
    &copy; Copyright <strong><span>Universitas Ibnu Sina</span></strong>. All Rights Reserved
  </div>
  <div class="credits">
    Designed by <a href="https://bootstrapmade.com/">Dimas Pradipto</a>
  </div>
</footer><!-- End Footer -->
<?php /**PATH C:\laragon\www\warga\resources\views/layouts/footer.blade.php ENDPATH**/ ?>