

<?php $__env->startSection('content'); ?>
  <div class="card shadow mb-4 col-12">
    <div class="card-header py-3">
      <a href="<?php echo e(route('pekerjaan.create')); ?>" class="btn btn-success"><i class="bi bi-plus"></i> Tambah</a>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table id="table" class="table table-striped" style="width:100%">
          <thead>
            <tr>
              <th>No</th>
              <th>Nama Pekerjaan</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $pekerjaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th><?php echo e($loop->iteration); ?></th>
                <th><?php echo e($p->pekerjaan); ?></th>
                <th>
                  <a href="pekerjaan/<?php echo e($p->id); ?>/edit" class="btn btn-warning text-white"><i
                      class="bi bi-pencil"></i></a>
                  <form action="pekerjaan/<?php echo e($p->id); ?>" method="POST" class="d-inline mt-2">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button type="submit" class="btn btn-danger"><i class="bi bi-trash"></i></button>
                  </form>
                </th>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\warga\resources\views/pages/pekerjaan/index.blade.php ENDPATH**/ ?>