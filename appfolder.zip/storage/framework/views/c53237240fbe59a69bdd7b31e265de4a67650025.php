

<?php $__env->startSection('content'); ?>
  <div class="card shadow mb-4 col-12">
    <div class="card-header">
      <a href="<?php echo e(route('kartukeluarga.index')); ?>" class="btn btn-warning text-white"><i class="bi bi-box-arrow-left"></i>
        Kembali</a>
    </div>
    <div class="card-body">
      <h5 class="card-title">Form Tambah Kapala Keluarga</h5>

      <!-- General Form Elements -->
      <form action="<?php echo e(route('kartukeluarga.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="row mb-3">
          <label for="inputText" class="col-sm-2 col-form-label">Nomor KK</label>
          <div class="col-sm-10">
            <input type="number" name="no_kk" value="<?php echo e(old('no_kk')); ?>" class="form-control"
              placeholder="nomor kartu keluarga" required>
            <div class="invalid-feedback">Masukkan nomor KK!!!</div>
          </div>
        </div>

        <div class="row mb-3">
          <label for="inputText" class="col-sm-2 col-form-label">Kepala Keluarga</label></label>
          <div class="col-sm-10">
            <input type="text" name="kepala_keluarga" value="<?php echo e(old('kepala_keluarga')); ?>" class="form-control"
              placeholder="Nama kepala keluarga" required>
          </div>
        </div>

        

        <div class="row mb-3">
          <label for="inputText" class="col-sm-2 col-form-label">Alamat</label>
          <div class="col-sm-10">
            <input type="text" name="alamat" value="<?php echo e(old('alamat')); ?>" placeholder="alamat" class="form-control"
              required>
            <div class="invalid-feedback">Masukkan Alamat Kamu!!!</div>
          </div>
        </div>

        <div class="row mb-3">
          <label for="inputText" class="col-sm-2 col-form-label">RT/RW</label>
          <div class="col-sm-5 mb-3">
            <input type="text" name="rt" value="<?php echo e(old('rt')); ?>" class="form-control" placeholder="001"
              required>
            <div class="invalid-feedback">Masukkan RT Kamu!!!</div>
          </div>
          <div class="col-sm-5">
            <input type="text" name="rw" value="<?php echo e(old('rw')); ?>" class="form-control" placeholder="001"
              required>
            <div class="invalid-feedback">Masukkan RW Kamu!!!</div>
          </div>
        </div>

        <div class="row mb-3">
          <label for="inputText" class="col-sm-2 col-form-label">Kelurahan</label>
          <div class="col-sm-10">
            <input type="text" name="kelurahan" value="<?php echo e(old('kelurahan')); ?>" placeholder="kelurahan"
              class="form-control" required>
            <div class="invalid-feedback">Masukkan kelurahan Kamu!!!</div>
          </div>
        </div>


        <div class="row mb-3">
          <label for="inputText" class="col-sm-2 col-form-label">Kecamatan</label>
          <div class="col-sm-10">
            <input type="text" name="kecamatan" value="<?php echo e(old('kecamatan')); ?>" placeholder="kecamatan"
              class="form-control" required>
            <div class="invalid-feedback">Masukkan kelurahan Kamu!!!</div>
          </div>
        </div>

        <div class="row mb-3">
          <label for="inputText" class="col-sm-2 col-form-label">Kabupaten</label>
          <div class="col-sm-10">
            <input type="text" name="kabupaten" value="<?php echo e(old('kabupaten')); ?>" placeholder="kabupaten"
              class="form-control" required>
            <div class="invalid-feedback">Masukkan nama kabupaten!!!</div>
          </div>
        </div>

        <div class="row mb-3">
          <label for="inputText" class="col-sm-2 col-form-label">Provinsi</label>
          <div class="col-sm-10">
            <input type="text" name="provinsi" value="<?php echo e(old('provinsi')); ?>" placeholder="provinsi"
              class="form-control" required>
            <div class="invalid-feedback">Masukkan provinsi!!!</div>
          </div>
        </div>

        <div class="row mb-3">
          <label class="col-sm-2 col-form-label"></label>
          <div class="col-sm-10">
            <button type="submit" class="btn btn-primary">Save</button>
          </div>
        </div>

      </form>

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\wargabatam\resources\views/pages/kartukeluarga/create.blade.php ENDPATH**/ ?>