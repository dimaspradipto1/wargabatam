  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link " href="<?php echo e(route('admin')); ?>">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li>

      <li class="nav-heading">WARGA</li>

      <?php if(Auth::user()->role == 'admin'): ?>
        <li class="nav-item">
          <a class="nav-link collapsed" href="<?php echo e(route('warga.index')); ?>">
            <i class="bi bi-person-fill"></i>
            <span>Warga</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link collapsed" href="<?php echo e(route('kartukeluarga.index')); ?>">
            <i class="bi bi-people-fill"></i>
            <span>Kartu Keluarga</span>
          </a>
        </li>

        <li class="nav-heading">PENGELOLAAN WARGA</li>

        <li class="nav-item">
          <a class="nav-link collapsed" href="<?php echo e(route('pendatang.index')); ?>">
            <i class="bi bi-person-fill-check"></i>
            <span>Data Pendatang</span>
          </a>
        </li><!-- End Pendatang Nav -->

        <li class="nav-item">
          <a class="nav-link collapsed" href="<?php echo e(route('pindah.index')); ?>">
            <i class="bi bi-person-fill-x"></i>
            <span>Data Pindah</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link collapsed" href="<?php echo e(route('kelahiran.index')); ?>">
            <i class="bi bi-person-fill-add"></i>
            <span>Data Kelahiran</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link collapsed" href="<?php echo e(route('kematian.index')); ?>">
            <i class="bi bi-person-fill-dash"></i>
            <span>Data Kematian</span>
          </a>
        </li>

        <li class="nav-heading">DATA LAIINYA</li>

        <li class="nav-item">
          <a class="nav-link collapsed" href="<?php echo e(route('pendidikan.index')); ?>">
            <i class="bi bi-book-fill"></i>
            <span>Pendidikan</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link collapsed" href="<?php echo e(route('pendidikan.index')); ?>">
            <i class="bi bi-building-fill"></i>
            <span>Pekerjaan</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link collapsed" href="<?php echo e(route('keperluan.index')); ?>">
            <i class="bi bi-search"></i>
            <span>Keperluan</span>
          </a>
        </li>

        <li class="nav-heading">PENGELOLAAN SURAT</li>

        <li class="nav-item">
          <a class="nav-link collapsed" href="<?php echo e(route('suratpengantarrt.index')); ?>">
            <i class="bi bi-house-fill"></i>
            <span>Pengantar RT</span>
          </a>
        </li>
        <li class="nav-heading">PENGELOLAAN user</li>

        <li class="nav-item">
          <a class="nav-link collapsed" href="<?php echo e(route('user.index')); ?>">
            <i class="bi bi-person-fill"></i>
            <span>Pengguna Sistem</span>
          </a>
        </li>
      <?php endif; ?>

      <?php if(Auth::user()->role == 'warga'): ?>
        <li class="nav-item">
          <a class=" nav-link collapsed" href="<?php echo e(route('warga.index')); ?>">
            <i class="bi bi-person-fill"></i>
            <span>Warga</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link collapsed " href="<?php echo e(route('kartukeluarga.index')); ?>">
            <i class="bi bi-people-fill"></i>
            <span>Kartu Keluarga</span>
          </a>
        </li>
        <li class="nav-heading">PENGELOLAAN SURAT</li>

        <li class="nav-item">
          <a class="nav-link collapsed " href="<?php echo e(route('suratpengantarrt.index')); ?>">
            <i class="bi bi-house-fill"></i>
            <span>Pengantar RT</span>
          </a>
        </li>
      <?php endif; ?>

      <?php if(Auth::user()->role == 'rt'): ?>
        <li class="nav-item">
          <a class="nav-link collapsed" href="<?php echo e(route('warga.index')); ?>">
            <i class="bi bi-person-fill"></i>
            <span>Warga</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link collapsed" href="<?php echo e(route('kartukeluarga.index')); ?>">
            <i class="bi bi-people-fill"></i>
            <span>Kartu Keluarga</span>
          </a>
        </li>
        <li class="nav-heading">PENGELOLAAN SURAT</li>

        <li class="nav-item">
          <a class="nav-link collapsed" href="<?php echo e(route('pendatang.index')); ?>">
            <i class="bi bi-person-fill-check"></i>
            <span>Data Pendatang</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link collapsed" href="<?php echo e(route('pindah.index')); ?>">
            <i class="bi bi-person-fill-x"></i>
            <span>Data Pindah</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link collapsed" href="<?php echo e(route('kelahiran.index')); ?>">
            <i class="bi bi-person-fill-add"></i>
            <span>Data Kelahiran</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link collapsed" href="<?php echo e(route('kematian.index')); ?>">
            <i class="bi bi-person-fill-dash"></i>
            <span>Data Kematian</span>
          </a>
        </li>

        <li class="nav-heading">PENGELOLAAN SURAT</li>

        <li class="nav-item">
          <a class="nav-link collapsed" href="<?php echo e(route('suratpengantarrt.index')); ?>">
            <i class="bi bi-house-fill"></i>
            <span>Pengantar RT</span>
          </a>
        </li>
      <?php endif; ?>
    </ul>

  </aside><!-- End Sidebar-->
<?php /**PATH C:\laragon\www\wargabatam\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>